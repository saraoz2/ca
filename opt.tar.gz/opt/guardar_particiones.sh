#!/bin/bash

# Archivo de destino
DESTINO="/opt/particion"

# Copiar el contenido de /proc/partitions al archivo persistente
cat /proc/partitions > "$DESTINO"

# Opcional: mostrar mensaje
echo "Contenido de /proc/partitions guardado en $DESTINO"
