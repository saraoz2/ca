#!/bin/bash
# ============================================================
# Script: backup_full.sh
# Descripción: Realiza backups comprimidos de directorios
#              con nombre que incluye la fecha (YYYYMMDD)
# ============================================================

# --- Función de ayuda ---
mostrar_ayuda() {
    echo "Uso: $0 <origen> <destino>"
    echo
    echo "Ejemplo:"
    echo "  $0 /var/log /backup_dir"
    echo
    echo "Opciones:"
    echo "  -help     Muestra esta ayuda"
    exit 0
}

# --- Verificar si se pidió ayuda ---
if [[ "$1" == "-help" ]]; then
    mostrar_ayuda
fi

# --- Validar argumentos ---
if [[ $# -ne 2 ]]; then
    echo "Error: Se requieren dos argumentos (origen y destino)."
    echo "Use -help para más información."
    exit 1
fi

ORIGEN="$1"
DESTINO="$2"
FECHA=$(date +%Y%m%d)

# --- Validar que el origen exista ---
if [[ ! -d "$ORIGEN" ]]; then
    echo "Error: El directorio de origen '$ORIGEN' no existe."
    exit 2
fi

# --- Validar que el destino esté montado ---
if ! mountpoint -q "$DESTINO"; then
    echo "Error: El destino '$DESTINO' no está montado o disponible."
    exit 3
fi

# --- Crear el nombre del archivo ---
NOMBRE=$(basename "$ORIGEN")
ARCHIVO="${NOMBRE}_bkp_${FECHA}.tar.gz"
RUTA_FINAL="${DESTINO}/${ARCHIVO}"

# --- Realizar el backup ---
echo "Iniciando backup de '$ORIGEN' a '$RUTA_FINAL'..."
tar -czf "$RUTA_FINAL" -C "$(dirname "$ORIGEN")" "$NOMBRE"

# --- Verificar resultado ---
if [[ $? -eq 0 ]]; then
    echo "Backup completado con éxito: $RUTA_FINAL"
else
    echo "Error: Falló la creación del backup."
    exit 4
fi

exit 0
